///////////////////////////////////////////////////////////////////////////////////////
//
//  Contract.java
//  Inventory App For SQlite and Contract
//
//  column contract class
//
//  Created by Xiaoming Yu  on 01/29/2018.
//
///////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.tourist.inventory;

import android.provider.BaseColumns;

public class Contract {
    public static class Entry implements BaseColumns {
        // member variable
        //table name
        static final String BOOK_TABLE_NAME = "books";

        // Columns names
        static final String COLUMN_BOOK_ID = "id";
        static final String COLUMN_BOOK_TITLE = "title";
        static final String COLUMN_BOOK_AUTHOR = "author";
        static final String COLUMN_BOOK_PRICE = "price";
        static final String COLUMN_BOOK_QUANTITY = "quantity";
        static final String COLUMN_BOOK_SUPPLIERNAME = "suppliername";
        static final String COLUMN_BOOK_SUPPLIEREMAIL = "supplieremail";
        static final String COLUMN_BOOK_SUPPLIERPHONE = "supplierphone";
    }
}
