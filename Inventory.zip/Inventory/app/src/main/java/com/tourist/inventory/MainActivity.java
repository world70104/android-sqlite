////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  MainActivity.java
//  Inventory App For SQlite and Contract
//
//  Created by Xiaoming Yu  on 01/29/2018.
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.tourist.inventory;

// import class name
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.database.Cursor;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

// MainActivity class
public class MainActivity extends AppCompatActivity {
    private DbHelper m_dbHelper ;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // MainActivity create
    //
    // inp: savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DbHelper m_db = new DbHelper(this);
        // Inserting Book/Rows
        Log.d("Insert: ", "Inserting ..");
        m_db.insertData(new Book("Android Programming", "Kristin Marsicano", 20,
                "1.5 mil", "Nerd Ranch, LLC",
                "Supplier@NerdRanch.com", "+1-234-44568945"));
        m_db.insertData(new Book("Hello Android", "ED vernet", 15, "1 mil",
                "Nokia publish",
                "Supplier@nokiapublish.com", "+40-234-98766078"));

        // Reading all books
        Log.d("Reading: ", "Reading all books..");
        Cursor cursor = m_db.queryData();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Book book = new Book();
                book.setId(Integer.parseInt(cursor.getString(0)));
                book.setTitle(cursor.getString(1));
                book.setAuthor(cursor.getString(2));
                book.setPrice(cursor.getInt(3));
                book.setQuantity(cursor.getString(4));
                book.setSuppliername(cursor.getString(5));
                book.setSupplieremail(cursor.getString(6));
                book.setSupplierphone(cursor.getString(7));

                // Adding contact to list
                String log = "Id: " + book.getId() + " ,Title: " + book.getTitle() + " ,Author: "
                        + book.getAuthor()+ " ,Price: " + Integer.toString(book.getPrice() )
                        + " ,Quantity: " + book.getQuantity() + " ,Suppliername: " + book.getSuppliername()
                        + " ,Supplieremail: " + book.getSupplieremail()
                        + " ,Supplierphone: " + book.getSupplierphone();
                // Writing books  to log
                Log.d("Book: : ", log);
            } while (cursor.moveToNext());
        }
    }
}
