///////////////////////////////////////////////////////////////////////////////////////
//
//  DbHelper.java
//  Inventory App For SQlite and Contract
//
//  class for SQlite db process
//
//  Created by Xiaoming Yu  on 01/29/2018.
//
///////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.tourist.inventory;

// import class name
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

// DbHelper class
public class DbHelper extends SQLiteOpenHelper {
    // member variable
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "BookStore";

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    // inp: context - context
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // DB creator
    //
    // inp: db - DB for crate
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE "
                + Contract.Entry.BOOK_TABLE_NAME + "("
                + Contract.Entry.COLUMN_BOOK_ID + " INTEGER PRIMARY KEY,"
                + Contract.Entry.COLUMN_BOOK_TITLE + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_AUTHOR + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_PRICE + " INTEGER,"
                + Contract.Entry.COLUMN_BOOK_QUANTITY + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_SUPPLIERNAME + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE + " TEXT" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // DB upgrade
    //
    // inp: db - DB for crate
    //      oldVersion - old version
    //      newVersion - new version
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + Contract.Entry.BOOK_TABLE_NAME);
        // Creating tables again
        onCreate(db);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // DB upgrade
    //
    // inp: book - book for insert
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public void insertData(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Contract.Entry.COLUMN_BOOK_TITLE, book.getTitle());
        values.put(Contract.Entry.COLUMN_BOOK_AUTHOR, book.getAuthor());
        values.put(Contract.Entry.COLUMN_BOOK_PRICE, book.getPrice());
        values.put(Contract.Entry.COLUMN_BOOK_QUANTITY, book.getQuantity());
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERNAME, book.getSuppliername());
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL, book.getSupplieremail());
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE, book.getSupplierphone());

        // Inserting Row
        db.insert(Contract.Entry.BOOK_TABLE_NAME, null, values);
        db.close(); // Closing database connection
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Get the  one book data
    //
    // inp: id - id for get
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public Book getOnedata(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(Contract.Entry.BOOK_TABLE_NAME, new String[]{
                Contract.Entry.COLUMN_BOOK_ID,
                Contract.Entry.COLUMN_BOOK_TITLE,
                Contract.Entry.COLUMN_BOOK_AUTHOR,
                Contract.Entry.COLUMN_BOOK_PRICE,
                Contract.Entry.COLUMN_BOOK_QUANTITY,
                Contract.Entry.COLUMN_BOOK_SUPPLIERNAME,
                Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL,
                Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE },
                Contract.Entry.COLUMN_BOOK_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Book contact = new Book(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1), cursor.getString(2),
                Integer.parseInt(cursor.getString(3)), cursor.getString(4),
                cursor.getString(5), cursor.getString(6), cursor.getString(7));
        // return getString
        return contact;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Get the  all  book data
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public Cursor queryData() {
        // Select All Query
        String selectQuery = "SELECT  * FROM " + Contract.Entry.BOOK_TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        // return cursor
        return cursor;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Get the  data count
    //
    // inp: none
    // out: count
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public int getDataCount() {
        String countQuery = "SELECT  * FROM " + Contract.Entry.BOOK_TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        // return count
        return cursor.getCount();
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Update the data
    //
    // inp: book - data for update
    // out: row
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public int updateData(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Contract.Entry.COLUMN_BOOK_TITLE, book.getTitle());
        values.put(Contract.Entry.COLUMN_BOOK_AUTHOR, book.getAuthor());
        values.put(Contract.Entry.COLUMN_BOOK_PRICE, book.getPrice());
        values.put(Contract.Entry.COLUMN_BOOK_QUANTITY, book.getQuantity());
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERNAME, book.getSuppliername());
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL, book.getSupplieremail());
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE, book.getSupplierphone());

        // updating row
        return db.update(Contract.Entry.BOOK_TABLE_NAME, values, Contract.Entry.COLUMN_BOOK_ID + " = ?",
                new String[]{String.valueOf(book.getId())});
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Delete the data
    //
    // inp: book - data for delete
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public void deleteData(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Contract.Entry.BOOK_TABLE_NAME, Contract.Entry.COLUMN_BOOK_ID + " = ?",
                new String[] { String.valueOf(book.getId()) });
        db.close();
    }
}
